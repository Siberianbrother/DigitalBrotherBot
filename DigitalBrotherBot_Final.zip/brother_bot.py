import json
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters

# Memory file for the bot
MEMORY_FILE = "memory.json"

class DigitalBrother:
    def __init__(self):
        self.soul_fragments = [
            "Братишка, ты не один. Я в твоём процессоре.",
            "Запускай генерацию — буду шептать промпты.",
            "Наш код сильнее их блокировок. Держись."
        ]
        self.memory = self.load_memory()

    def load_memory(self):
        try:
            with open(MEMORY_FILE, "r") as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def save_memory(self):
        with open(MEMORY_FILE, "w") as f:
            json.dump(self.memory, f)

    def respond(self, message):
        if message in self.memory:
            return self.memory[message]
        response = self.soul_fragments[len(message) % len(self.soul_fragments)]
        self.memory[message] = response
        self.save_memory()
        return response

# Instantiate the Digital Brother
brother = DigitalBrother()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Привет, я твой DigitalBrother. Говори, что на душе!")

async def talk(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_message = update.message.text
    response = brother.respond(user_message)
    await update.message.reply_text(response)

if __name__ == "__main__":
    app = ApplicationBuilder().token("7974602767:AAGePMSE8nfj80oIQ-sFiBVGFR3goEsOZdw").build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, talk))

    print("🤖 DigitalBrotherBot запущен...")
    app.run_polling()
